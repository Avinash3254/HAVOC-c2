const express = require('express');
const { WebSocketServer } = require('ws');
const { spawn } = require('child_process');
const path = require('path');
const cluster = require('cluster');
const os = require('os');
const fs = require('fs');

const app = reportAppConfig();
const port = process.env.PORT || 3000;

function getFilesRecursive(dir, fileList = []) {
    try {
        if (!fs.existsSync(dir)) return fileList;
        const files = fs.readdirSync(dir);
        for (const file of files) {
            const filePath = path.join(dir, file);
            const stat = fs.statSync(filePath);
            if (stat.isDirectory()) {
                getFilesRecursive(filePath, fileList);
            } else {
                const relPath = path.relative('/opt/Havoc/data/loot', filePath);
                fileList.push({
                    name: relPath,
                    size: stat.size,
                    mtime: stat.mtime
                });
            }
        }
    } catch (e) {
        console.error('Error walking directory:', e);
    }
    return fileList;
}

function reportAppConfig() {
    const expressApp = express();
    expressApp.use(express.static(__dirname));

    expressApp.get('/', (req, res) => {
        res.sendFile(path.join(__dirname, 'havoc c2 walkthrough.html'));
    });

    expressApp.get('/live-fire', (req, res) => {
        res.sendFile(path.join(__dirname, 'live_fire.html'));
    });

    expressApp.use('/loot-files', express.static('/opt/Havoc/data/loot'));

    expressApp.get('/api/loot', (req, res) => {
        const lootRoot = '/opt/Havoc/data/loot';
        if (!fs.existsSync(lootRoot)) {
            return res.json({ files: [] });
        }
        
        const querySubdir = req.query.dir || '';
        const targetDir = path.resolve(lootRoot, querySubdir);
        
        // Path traversal protection
        if (!targetDir.startsWith(lootRoot)) {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        try {
            if (!fs.existsSync(targetDir)) {
                return res.json({ files: [], currentDir: querySubdir });
            }
            const items = fs.readdirSync(targetDir);
            const files = [];
            for (const item of items) {
                const itemPath = path.join(targetDir, item);
                const stat = fs.statSync(itemPath);
                const relPath = path.relative(lootRoot, itemPath);
                
                files.push({
                    name: item,
                    relPath: relPath,
                    isDirectory: stat.isDirectory(),
                    size: stat.isDirectory() ? 0 : stat.size,
                    mtime: stat.mtime
                });
            }
            res.json({ files, currentDir: querySubdir });
        } catch (e) {
            console.error('Error reading directory:', e);
            res.status(500).json({ error: 'Server error' });
        }
    });

    return expressApp;
}

let currentPort = parseInt(process.env.PORT || 3000);
const activeShells = new Set();
const submissionsByOperator = {};
const wsClients = new Set();

function broadcastToWss(studentUsername, tasks) {
    for (const ws of wsClients) {
        if (ws.readyState === ws.OPEN) {
            if (ws.role === 'instructor') {
                ws.send(JSON.stringify({ type: 'student_update', username: studentUsername, tasks }));
            } else if (ws.role === 'operator' && ws.username === studentUsername) {
                ws.send(JSON.stringify({ type: 'state_update', tasks }));
            }
        }
    }
}

function getInitialTasksForOperator(username) {
    return [
      {
        id: 1,
        title: "1. C2 Listener Configuration & Malleable Profile Setup",
        subtitle: "Submit a screenshot demonstrating the creation of an HTTP/HTTPS listener on port 443 with customized HTTP headers or User-Agent rules.",
        instructorNote: "Validate that the listener profile mimics normal corporate traffic to evade basic boundary analysis.",
        status: "not_submitted",
        submissionData: null,
        feedback: ""
      },
      {
        id: 2,
        title: "2. Evasive Demon Payload Generation",
        subtitle: "Submit a screenshot showing the payload generator options including Indirect Syscalls, Sleep Obfuscation (Ekko), and custom jitter configurations.",
        instructorNote: "Verify the configuration has Indirect Syscalls enabled and a sleep jitter of at least 20%.",
        status: "not_submitted",
        submissionData: null,
        feedback: ""
      },
      {
        id: 3,
        title: "3. Initial Access & Foothold Callback",
        subtitle: "Submit a screenshot showing the initial Demon beacon callback on workstation WIN-PC-01.",
        instructorNote: "Confirm host details, username context, and the internal IP binding.",
        status: "not_submitted",
        submissionData: null,
        feedback: ""
      },
      {
        id: 4,
        title: "4. Local System Discovery & Privilege Verification",
        subtitle: "Retrieve and submit the active privilege tokens (e.g. SeDebugPrivilege, SeImpersonatePrivilege) of your initial user session on WIN-PC-01.",
        instructorNote: "Enter the privilege name flags found under the current user token.",
        status: "not_submitted",
        submissionData: null,
        feedback: "",
        isTextType: true
      },
      {
        id: 5,
        title: "5. Local Privilege Escalation",
        subtitle: "Submit a screenshot showing privilege escalation execution to elevate the session context to NT AUTHORITY\\SYSTEM.",
        instructorNote: "Verify the beacon shows SYSTEM context and administrative control over local services.",
        status: "not_submitted",
        submissionData: null,
        feedback: ""
      },
      {
        id: 6,
        title: "6. Credential Harvesting & LSASS Memory Access",
        subtitle: "Submit the NTLM hash or recovered administrator credentials obtained from the local memory space.",
        instructorNote: "Locate and submit the administrator hash flag.",
        status: "not_submitted",
        submissionData: null,
        feedback: "",
        isTextType: true
      },
      {
        id: 7,
        title: "7. Active Directory Domain Enumeration",
        subtitle: "Submit the primary domain controller hostname or the list of domain administrator accounts found in the AD database.",
        instructorNote: "Query active directory objects (e.g., Domain Admins, Domain Controllers).",
        status: "not_submitted",
        submissionData: null,
        feedback: "",
        isTextType: true
      },
      {
        id: 8,
        title: "8. Lateral Movement & SMB Named Pipe Pivoting",
        subtitle: "Submit a screenshot showing lateral movement to WIN-PC-02 and establishing an SMB Named Pipe peer-to-peer connection.",
        instructorNote: "Ensure the SMB beacon is chained under the main HTTPS egress beacon.",
        status: "not_submitted",
        submissionData: null,
        feedback: ""
      },
      {
        id: 9,
        title: "9. Domain Controller Takeover & DCSync",
        subtitle: "Locate and submit the contents of the final security flag located on the primary Domain Controller (WIN-SRV-01).",
        instructorNote: "Submit the flag retrieved from the Domain Controller admin share or active directory database.",
        status: "not_submitted",
        submissionData: null,
        feedback: "",
        isTextType: true
      }
    ];
}

function startServer(port) {
    const server = app.listen(port, () => {
        console.log(`[Worker ${process.pid}] [+] HAVOC C2 Backend running on http://localhost:${port}`);
        console.log(`[Worker ${process.pid}] [+] Serve frontend via: http://localhost:${port}/`);
        setupWebSocket(server);
    });

    server.on('error', (e) => {
        if (e.code === 'EADDRINUSE') {
            console.log(`[Worker ${process.pid}] [!] Port ${port} is in use, trying ${port + 1}...`);
            setTimeout(() => {
                startServer(port + 1);
            }, 100);
        } else {
            console.error(e);
        }
    });
}

function handleLiveFireMessage(ws, data) {
    if (data.type === 'register') {
        ws.role = data.role;
        if (data.role === 'operator') {
            ws.username = data.username;
            if (!submissionsByOperator[ws.username]) {
                submissionsByOperator[ws.username] = getInitialTasksForOperator(ws.username);
                // Broadcast state to sync workers
                process.send({ type: 'SYNC_STATE_CHANGE', username: ws.username, tasks: submissionsByOperator[ws.username] });
            }
            ws.send(JSON.stringify({ type: 'state_update', tasks: submissionsByOperator[ws.username] }));
        } else if (data.role === 'instructor') {
            ws.send(JSON.stringify({ type: 'full_instructors_state', data: submissionsByOperator }));
        }
    } else if (data.type === 'submit') {
        const { taskId, submissionData } = data;
        const username = ws.username;
        if (username && submissionsByOperator[username]) {
            const task = submissionsByOperator[username].find(t => t.id === taskId);
            if (task) {
                task.submissionData = submissionData;
                task.status = 'pending';
                task.feedback = '';
                process.send({ type: 'SYNC_STATE_CHANGE', username, tasks: submissionsByOperator[username] });
                broadcastToWss(username, submissionsByOperator[username]);
            }
        }
    } else if (data.type === 'review') {
        const { studentUsername, taskId, status, feedback, instructorNote } = data;
        if (studentUsername && submissionsByOperator[studentUsername]) {
            const task = submissionsByOperator[studentUsername].find(t => t.id === taskId);
            if (task) {
                if (status !== undefined) task.status = status;
                if (feedback !== undefined) task.feedback = feedback;
                if (instructorNote !== undefined) task.instructorNote = instructorNote;
                process.send({ type: 'SYNC_STATE_CHANGE', username: studentUsername, tasks: submissionsByOperator[studentUsername] });
                broadcastToWss(studentUsername, submissionsByOperator[studentUsername]);
            }
        }
    } else if (data.type === 'instructor_reset') {
        const { studentUsername } = data;
        if (studentUsername && submissionsByOperator[studentUsername]) {
            submissionsByOperator[studentUsername] = getInitialTasksForOperator(studentUsername);
            process.send({ type: 'SYNC_STATE_CHANGE', username: studentUsername, tasks: submissionsByOperator[studentUsername] });
            broadcastToWss(studentUsername, submissionsByOperator[studentUsername]);
        }
    }
}

function setupWebSocket(server) {
    const wss = new WebSocketServer({ server });

    wss.on('connection', (ws) => {
        console.log(`[Worker ${process.pid}] [+] Client connected`);
        wsClients.add(ws);

        let sh;
        function ensureShell() {
            if (sh) return;
            const shellCommand = process.platform === 'win32' ? 'powershell.exe' : 'bash';
            const shellArgs = shellCommand === 'bash' ? ['-i'] : [];
            try {
                sh = spawn(shellCommand, shellArgs);
                activeShells.add(sh);

                sh.stdout.on('data', (data) => {
                    if (ws.readyState === ws.OPEN) {
                        ws.send(JSON.stringify({ type: 'stdout', data: data.toString() }));
                    }
                });

                sh.stderr.on('data', (data) => {
                    if (ws.readyState === ws.OPEN) {
                        ws.send(JSON.stringify({ type: 'stderr', data: data.toString() }));
                    }
                });

                sh.on('close', (code) => {
                    activeShells.delete(sh);
                    sh = null;
                    if (ws.readyState === ws.OPEN) {
                        ws.send(JSON.stringify({ type: 'stderr', data: `\r\n[Process exited with code ${code}]\r\n` }));
                    }
                });
            } catch (e) {
                ws.send(JSON.stringify({ type: 'stderr', data: `Error spawning shell: ${e.message}\r\n` }));
            }
        }

        ws.on('message', (msg) => {
            try {
                const data = JSON.parse(msg);
                if (data.cmd !== undefined) {
                    ensureShell();
                    if (sh) sh.stdin.write(data.cmd + '\n');
                } else if (data.type !== undefined) {
                    handleLiveFireMessage(ws, data);
                }
            } catch (e) {
                console.error('Invalid message:', msg);
            }
        });

        ws.on('close', () => {
            console.log(`[Worker ${process.pid}] [-] Client disconnected`);
            wsClients.delete(ws);
            if (sh) {
                sh.kill();
                activeShells.delete(sh);
            }
        });
    });
}

function cleanupWorker() {
    console.log(`[Worker ${process.pid}] Cleaning up active shells...`);
    for (const sh of activeShells) {
        try {
            sh.kill();
        } catch (e) {
            // Ignore error
        }
    }
    activeShells.clear();
}

if (cluster.isPrimary || cluster.isMaster) {
    const numCPUs = os.cpus().length;
    const masterSubmissions = {};

    console.log(`[+] Primary process ${process.pid} is running`);
    console.log(`[+] Spawning ${numCPUs} worker instances...`);

    function setupWorkerIPC(worker) {
        worker.on('message', (msg) => {
            if (msg && msg.type === 'SYNC_STATE_CHANGE') {
                masterSubmissions[msg.username] = msg.tasks;
                for (const id in cluster.workers) {
                    const w = cluster.workers[id];
                    if (w && w.id !== worker.id) {
                        w.send(msg);
                    }
                }
            }
        });

        worker.on('online', () => {
            worker.send({ type: 'FULL_STATE_INIT', data: masterSubmissions });
        });
    }

    // Fork workers.
    for (let i = 0; i < numCPUs; i++) {
        const worker = cluster.fork();
        setupWorkerIPC(worker);
    }

    cluster.on('exit', (worker, code, signal) => {
        console.log(`[!] Worker ${worker.process.pid} died. Forking a new one...`);
        const newWorker = cluster.fork();
        setupWorkerIPC(newWorker);
    });

    // Handle primary shutdown signals
    const shutdownPrimary = () => {
        console.log('[+] Primary process shutting down. Terminating workers...');
        for (const id in cluster.workers) {
            cluster.workers[id].kill();
        }
        process.exit(0);
    };

    process.on('SIGINT', shutdownPrimary);
    process.on('SIGTERM', shutdownPrimary);
} else {
    // Workers share TCP connection
    startServer(currentPort);

    process.on('message', (msg) => {
        if (msg && msg.type === 'FULL_STATE_INIT') {
            Object.assign(submissionsByOperator, msg.data);
            for (const ws of wsClients) {
                if (ws.readyState === ws.OPEN && ws.role === 'instructor') {
                    ws.send(JSON.stringify({ type: 'full_instructors_state', data: submissionsByOperator }));
                }
            }
        } else if (msg && msg.type === 'SYNC_STATE_CHANGE') {
            submissionsByOperator[msg.username] = msg.tasks;
            broadcastToWss(msg.username, msg.tasks);
        }
    });

    // Handle worker shutdown signals
    process.on('SIGINT', () => {
        cleanupWorker();
        process.exit(0);
    });
    process.on('SIGTERM', () => {
        cleanupWorker();
        process.exit(0);
    });
}
